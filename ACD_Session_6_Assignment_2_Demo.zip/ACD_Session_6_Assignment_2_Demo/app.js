function FindGreatestAmongThree() {
  var num1 = 30.3;
  var num2 = 20.78;
  var num3 = 20.25;

  if(num1>num2 && num1>num3)
    console.log("Num1 (" + num1 + ") is greatest");
  else if (num2>num1 && num2>num3)
    console.log("Num2 (" + num2 + ") is greatest");
  else
    console.log("Num3 (" + num3 + ") is greatest");
}
